#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system('pip install snapml')


# In[2]:


#importing libraries


# In[3]:


from __future__ import print_function
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import normalize, StandardScaler, MinMaxScaler
from sklearn.utils.class_weight import compute_sample_weight
from sklearn.metrics import mean_squared_error
import time
import warnings
import gc, sys
warnings.filterwarnings('ignore')


# In[4]:


df = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/snapML.csv")
df.head()


# In[5]:


print("There are " + str(len(df)) + " observations in the dataset.")
print("There are " + str(len(df.columns)) + " variables in the dataset.")


# In[6]:


#reducing the data size


# In[7]:


df=df.head(100000)


# In[8]:


#cleaning data


# In[9]:


df = df[df['tip_amount'] > 0]
df = df[(df['tip_amount'] <= df['fare_amount'])]
df = df[((df['fare_amount'] >=2) & (df['fare_amount'] < 200))]
df1 = df.drop(['total_amount'], axis=1)


# In[10]:


del df
gc.collect()


# In[11]:


print("There are " + str(len(df1)) + " observations in the dataset.")
print("There are " + str(len(df1.columns)) + " variables in the dataset.")


# In[12]:


#histogram


# In[13]:


plt.hist(df1.tip_amount.values, 16, histtype='bar', facecolor='g')
plt.show()


# In[14]:


print("Minimum amount value is ", np.min(df1.tip_amount.values))
print("Maximum amount value is ", np.max(df1.tip_amount.values))
print("90% of the trips have a tip amount less or equal than ", np.percentile(df1.tip_amount.values, 90))


# In[15]:


df1.head()


# In[16]:


#data preprocessing


# In[17]:


df1['tpep_dropoff_datetime'] = pd.to_datetime(df1['tpep_dropoff_datetime'])
df1['tpep_pickup_datetime'] = pd.to_datetime(df1['tpep_pickup_datetime'])


# In[18]:


#pickup & dropoff hour


# In[19]:


df1['pickup_hour'] = df1['tpep_pickup_datetime'].dt.hour
df1['dropoff_hour'] = df1['tpep_dropoff_datetime'].dt.hour


# In[20]:


#pickup & dropoff day of week


# In[21]:


df1['pickup_day'] = df1['tpep_pickup_datetime'].dt.weekday
df1['dropoff_day'] = df1['tpep_dropoff_datetime'].dt.weekday


# In[22]:


#computing


# In[23]:


df1['trip_time'] = (df1['tpep_dropoff_datetime'] - df1['tpep_pickup_datetime']).astype('timedelta64[m]')


# In[24]:


first_n_rows = 1000000
df1 = df1.head(first_n_rows)


# In[25]:


#drop pickup & dropoff datetimes


# In[26]:


df1 = df1.drop(['tpep_pickup_datetime', 'tpep_dropoff_datetime'], axis=1)


# In[27]:


#one-hot encoding


# In[28]:


get_dummy_col = ["VendorID","RatecodeID","store_and_fwd_flag","PULocationID", "DOLocationID","payment_type", "pickup_hour", "dropoff_hour", "pickup_day", "dropoff_day"]
proc_data = pd.get_dummies(df1, columns = get_dummy_col)


# In[29]:


del df1
gc.collect()


# In[30]:


#labels


# In[31]:


y = proc_data[['tip_amount']].values.astype('float32')


# In[32]:


#target variable


# In[33]:


proc_data = proc_data.drop(['tip_amount'], axis=1)


# In[34]:


#feature matrix


# In[35]:


X = proc_data.values


# In[36]:


#normalizing


# In[37]:


X = normalize(X, axis=1, norm='l1', copy=False)


# In[38]:


print('X.shape=', X.shape)
print('y.shape=', y.shape)


# In[39]:


#train test split


# In[40]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)


# In[41]:


print('X_train.shape=', X_train.shape, 'Y_train.shape=', y_train.shape)
print('X_test.shape=', X_test.shape, 'Y_test.shape=', y_test.shape)


# In[42]:


#building decision tree with scikit learn


# In[43]:


from sklearn.tree import DecisionTreeRegressor


# In[44]:


sklearn_dt = DecisionTreeRegressor(max_depth=8, random_state=35)


# In[45]:


#training


# In[46]:


t0 = time.time()
sklearn_dt.fit(X_train, y_train)
sklearn_time = time.time()-t0
print("[Scikit-Learn] Training time (s):  {0:.5f}".format(sklearn_time))


# In[47]:


#building decision tree with snapML


# In[48]:


from snapml import DecisionTreeRegressor


# In[49]:


snapml_dt = DecisionTreeRegressor(max_depth=8, random_state=45, n_jobs=4)


# In[50]:


#training


# In[51]:


t0 = time.time()
snapml_dt.fit(X_train, y_train)
snapml_time = time.time()-t0
print("[Snap ML] Training time (s):  {0:.5f}".format(snapml_time))


# In[52]:


#evaluating


# In[53]:


training_speedup = sklearn_time/snapml_time
print('[Decision Tree Regressor] Snap ML vs. Scikit-Learn speedup : {0:.2f}x '.format(training_speedup))


# In[54]:


#predictions


# In[55]:


sklearn_pred = sklearn_dt.predict(X_test)
snapml_pred = snapml_dt.predict(X_test)


# In[56]:


#mean squared error


# In[57]:


sklearn_mse = mean_squared_error(y_test, sklearn_pred)
print('[Scikit-Learn] MSE score : {0:.3f}'.format(sklearn_mse))
snapml_mse = mean_squared_error(y_test, snapml_pred)
print('[Snap ML] MSE score : {0:.3f}'.format(snapml_mse))


# In[ ]:




