#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system('pip install scikit-learn==1.0.2')
get_ipython().system('pip install snapml')


# In[2]:


#importing libraries


# In[3]:


from __future__ import print_function
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import normalize, StandardScaler
from sklearn.utils.class_weight import compute_sample_weight
from sklearn.metrics import roc_auc_score
import time
import warnings
warnings.filterwarnings('ignore')


# In[4]:


df = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/snapML.csv")
df.head()


# In[5]:


print("There are " + str(len(df)) + " observations in the credit card fraud dataset.")
print("There are " + str(len(df.columns)) + " variables in the dataset.")


# In[6]:


#let n=10


# In[7]:


n = 10
df1 = pd.DataFrame(np.repeat(df.values, n, axis=0), columns=df.columns)


# In[8]:


print("There are " + str(len(df1)) + " observations in the inflated credit card fraud dataset.")
print("There are " + str(len(df1.columns)) + " variables in the dataset.")


# In[9]:


df1.head()


# In[10]:


#labels


# In[11]:


labels = df1.Class.unique()


# In[12]:


#sizes


# In[13]:


sizes = df1.Class.value_counts().values


# In[14]:


#plotting


# In[15]:


fig, ax = plt.subplots()
ax.pie(sizes, labels=labels, autopct='%1.3f%%')
ax.set_title('Target Variable Value Counts')
plt.show()


# In[16]:


#histogram


# In[17]:


plt.hist(df1.Amount.values, 6, histtype='bar', facecolor='g')
plt.show()


# In[18]:


#range


# In[19]:


print("Minimum amount value is ", np.min(df1.Amount.values))
print("Maximum amount value is ", np.max(df1.Amount.values))
print("90% of the transactions have an amount less or equal than ", np.percentile(df.Amount.values, 90))


# In[20]:


#data preprocessing


# In[21]:


df1.iloc[:, 1:30] = StandardScaler().fit_transform(df1.iloc[:, 1:30])
data = df1.values


# In[22]:


#feature matrix


# In[23]:


X = data[:, 1:30]


# In[24]:


#labels vector


# In[25]:


y = data[:, 30]


# In[26]:


#data normalization


# In[27]:


X = normalize(X, norm="l1")


# In[28]:


#shapes


# In[29]:


print('X.shape=', X.shape)
print('y.shape=', y.shape)


# In[30]:


#train test split


# In[31]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)       


# In[32]:


print('X_train.shape =', X_train.shape, 'Y_train.shape =', y_train.shape)
print('X_test.shape =', X_test.shape, 'Y_test.shape =', y_test.shape)


# In[33]:


#buliding decision tree classifier with scikit learn


# In[34]:


from sklearn.tree import DecisionTreeClassifier


# In[35]:


#computing sample weight


# In[36]:


train = compute_sample_weight('balanced', y_train)


# In[37]:


sklearn_dt = DecisionTreeClassifier(max_depth=4, random_state=35)


# In[38]:


#training


# In[39]:


t0 = time.time()
sklearn_dt.fit(X_train, y_train, sample_weight=train)
sklearn_time = time.time()-t0
print("[Scikit-Learn] Training time (s):  {0:.5f}".format(sklearn_time))


# In[40]:


#buliding decision tree classifier with snapML


# In[41]:


from snapml import DecisionTreeClassifier


# In[42]:


snapml_dt = DecisionTreeClassifier(max_depth=4, random_state=45, n_jobs=4)


# In[43]:


#training


# In[44]:


t0 = time.time()
snapml_dt.fit(X_train, y_train, sample_weight=train)
snapml_time = time.time()-t0
print("[Snap ML] Training time (s):  {0:.5f}".format(snapml_time))


# In[45]:


#evaluating both


# In[46]:


training_speedup = sklearn_time/snapml_time
print('[Decision Tree Classifier] Snap ML vs. Scikit-Learn speedup : {0:.2f}x '.format(training_speedup))


# In[47]:


#probability predictions


# In[48]:


sklearn_pred = sklearn_dt.predict_proba(X_test)[:,1]
snapml_pred = snapml_dt.predict_proba(X_test)[:,1]


# In[49]:


#ROC-AUC curve


# In[50]:


sklearn_roc_auc = roc_auc_score(y_test, sklearn_pred)
print('[Scikit-Learn] ROC-AUC score : {0:.3f}'.format(sklearn_roc_auc))


# In[51]:


snapml_roc_auc = roc_auc_score(y_test, snapml_pred)   
print('[Snap ML] ROC-AUC score : {0:.3f}'.format(snapml_roc_auc))


# In[52]:


#building SVM with scikit learn


# In[53]:


from sklearn.svm import LinearSVC


# In[54]:


sklearn_svm = LinearSVC(class_weight='balanced', random_state=31, loss="hinge", fit_intercept=False)


# In[55]:


#training


# In[56]:


t0 = time.time()
sklearn_svm.fit(X_train, y_train)
sklearn_time = time.time() - t0
print("[Scikit-Learn] Training time (s):  {0:.2f}".format(sklearn_time))


# In[57]:


#building SVM with snapML


# In[58]:


from snapml import SupportVectorMachine


# In[59]:


snapml_svm = SupportVectorMachine(class_weight='balanced', random_state=25, n_jobs=4, fit_intercept=False)


# In[60]:


#training


# In[61]:


t0 = time.time()
model = snapml_svm.fit(X_train, y_train)
snapml_time = time.time() - t0
print("[Snap ML] Training time (s):  {0:.2f}".format(snapml_time))


# In[62]:


#evaluating both


# In[63]:


training_speedup = sklearn_time/snapml_time
print('[Support Vector Machine] Snap ML vs. Scikit-Learn training speedup : {0:.2f}x '.format(training_speedup))


# In[64]:


#decision function predictions


# In[65]:


sklearn_pred = sklearn_svm.decision_function(X_test)
snapml_pred = snapml_svm.decision_function(X_test)


# In[66]:


#ROC-AUC curve


# In[67]:


acc_sklearn  = roc_auc_score(y_test, sklearn_pred)
print("[Scikit-Learn] ROC-AUC score:   {0:.3f}".format(acc_sklearn))
acc_snapml  = roc_auc_score(y_test, snapml_pred)
print("[Snap ML] ROC-AUC score:   {0:.3f}".format(acc_snapml))


# In[68]:


#confidence scores


# In[69]:


sklearn_pred = sklearn_svm.decision_function(X_test)
snapml_pred  = snapml_svm.decision_function(X_test)


# In[70]:


#hinge loss


# In[71]:


from sklearn.metrics import hinge_loss


# In[72]:


loss_snapml = hinge_loss(y_test, snapml_pred)
print("[Snap ML] Hinge loss:   {0:.3f}".format(loss_snapml))


# In[73]:


loss_sklearn = hinge_loss(y_test, sklearn_pred)
print("[Scikit-Learn] Hinge loss:   {0:.3f}".format(loss_snapml))


# In[ ]:




